package com.example.admutetv

import android.content.Context
import android.content.SharedPreferences

internal class SettingsRepository(context: Context) {
    private val preferences: SharedPreferences =
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        enabled = preferences.getBoolean(KEY_ENABLED, true),
        watchAllApps = preferences.getBoolean(KEY_WATCH_ALL_APPS, true),
        packageNames = splitLines(preferences.getString(KEY_PACKAGE_NAMES, "").orEmpty()),
        markers = splitLines(
            preferences.getString(KEY_MARKERS, DEFAULT_MARKERS).orEmpty()
        ).ifEmpty { DEFAULT_MARKER_SET },
        resumeDelayMs = preferences.getLong(KEY_RESUME_DELAY_MS, DEFAULT_RESUME_DELAY_MS),
        showOverlay = preferences.getBoolean(KEY_SHOW_OVERLAY, true)
    )

    fun save(settings: AppSettings) {
        preferences.edit()
            .putBoolean(KEY_ENABLED, settings.enabled)
            .putBoolean(KEY_WATCH_ALL_APPS, settings.watchAllApps)
            .putString(KEY_PACKAGE_NAMES, settings.packageNames.joinToString("\n"))
            .putString(KEY_MARKERS, settings.markers.joinToString("\n"))
            .putLong(KEY_RESUME_DELAY_MS, settings.resumeDelayMs)
            .putBoolean(KEY_SHOW_OVERLAY, settings.showOverlay)
            .apply()
    }

    fun setEnabled(enabled: Boolean) {
        preferences.edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    private fun splitLines(value: String): Set<String> =
        value.lineSequence()
            .map(String::trim)
            .filter(String::isNotEmpty)
            .toSet()

    data class AppSettings(
        val enabled: Boolean,
        val watchAllApps: Boolean,
        val packageNames: Set<String>,
        val markers: Set<String>,
        val resumeDelayMs: Long,
        val showOverlay: Boolean
    ) {
        fun appliesTo(packageName: String?): Boolean =
            watchAllApps || (packageName != null && packageName in packageNames)
    }

    companion object {
        private const val PREFERENCES_NAME = "ad_mute_settings"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_WATCH_ALL_APPS = "watch_all_apps"
        private const val KEY_PACKAGE_NAMES = "package_names"
        private const val KEY_MARKERS = "markers"
        private const val KEY_RESUME_DELAY_MS = "resume_delay_ms"
        private const val KEY_SHOW_OVERLAY = "show_overlay"

        const val DEFAULT_RESUME_DELAY_MS = 1_800L
        const val DEFAULT_MARKERS = "ad\nadvertisement\nsponsored\nad 1 of\nskip ad"
        val DEFAULT_MARKER_SET: Set<String> = DEFAULT_MARKERS.lineSequence().toSet()
    }
}
