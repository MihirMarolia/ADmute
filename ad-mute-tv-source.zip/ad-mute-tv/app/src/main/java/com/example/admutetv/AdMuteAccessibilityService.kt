package com.example.admutetv

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class AdMuteAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val detector = AdDetector()

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var volumeController: MediaVolumeController
    private lateinit var statusOverlay: StatusOverlay

    private var lastLikelyAdAtMs = 0L
    private var lastPackageName: String? = null
    private var pendingRestore: Runnable? = null
    private var commandReceiverRegistered = false

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == StatusContract.ACTION_RESTORE_NOW && ::volumeController.isInitialized) {
                cancelPendingRestore()
                restoreAndReport("Manual restore requested")
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        settingsRepository = SettingsRepository(this)
        volumeController = MediaVolumeController(this)
        statusOverlay = StatusOverlay(this)
        ContextCompat.registerReceiver(
            this,
            commandReceiver,
            IntentFilter(StatusContract.ACTION_RESTORE_NOW),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        commandReceiverRegistered = true
        publishStatus("Ready — watching for configured ad labels")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::volumeController.isInitialized) return

        val settings = settingsRepository.load()
        if (!settings.enabled) {
            cancelPendingRestore()
            restoreAndReport("Automation is turned off")
            return
        }

        val foregroundPackage = event.packageName?.toString()
        lastPackageName = foregroundPackage ?: lastPackageName
        if (foregroundPackage == packageName || !settings.appliesTo(foregroundPackage)) {
            scheduleRestore(settings.resumeDelayMs)
            return
        }

        val evidence = detector.inspect(
            root = rootInActiveWindow,
            eventTexts = event.text.toList(),
            markers = settings.markers
        )

        if (evidence.isAdLikely) {
            lastLikelyAdAtMs = System.currentTimeMillis()
            cancelPendingRestore()
            when (volumeController.mute()) {
                is MediaVolumeController.Result.Muted -> {
                    publishStatus(
                        "Muted media volume — label: ${evidence.matchedLabels.firstOrNull() ?: "ad"}",
                        isMuted = true,
                        overlayEnabled = settings.showOverlay
                    )
                }
                MediaVolumeController.Result.AlreadyMutedByUs -> {
                    publishStatus("Muted media volume — ad label still visible", true, settings.showOverlay)
                }
                MediaVolumeController.Result.AlreadyMutedExternally -> {
                    publishStatus("Possible ad label found — media was already muted", false, settings.showOverlay)
                }
                MediaVolumeController.Result.FixedVolumeDevice -> {
                    publishStatus("Possible ad label found — this TV has fixed media volume", false, settings.showOverlay)
                }
                else -> Unit
            }
        } else {
            scheduleRestore(settings.resumeDelayMs)
        }
    }

    override fun onInterrupt() {
        cancelPendingRestore()
        restoreAndReport("Accessibility service interrupted")
    }

    override fun onDestroy() {
        cancelPendingRestore()
        if (::volumeController.isInitialized) restoreAndReport("Accessibility service stopped")
        if (commandReceiverRegistered) unregisterReceiver(commandReceiver)
        if (::statusOverlay.isInitialized) statusOverlay.dismiss()
        super.onDestroy()
    }

    private fun scheduleRestore(delayMs: Long) {
        if (!volumeController.isMutedByUs || pendingRestore != null) return

        val elapsed = System.currentTimeMillis() - lastLikelyAdAtMs
        val waitMs = (delayMs - elapsed).coerceAtLeast(0L)
        val action = Runnable {
            pendingRestore = null
            restoreAndReport("Ad label no longer visible")
        }
        pendingRestore = action
        handler.postDelayed(action, waitMs)
    }

    private fun cancelPendingRestore() {
        pendingRestore?.let(handler::removeCallbacks)
        pendingRestore = null
    }

    private fun restoreAndReport(reason: String) {
        when (val result = volumeController.restore()) {
            is MediaVolumeController.Result.Restored ->
                publishStatus("Restored media volume to ${result.restoredVolume} — $reason")
            MediaVolumeController.Result.UserOrSystemChangedVolume ->
                publishStatus("Left current media volume unchanged — $reason")
            else -> publishStatus("Ready — $reason")
        }
    }

    private fun publishStatus(
        text: String,
        isMuted: Boolean = false,
        overlayEnabled: Boolean = settingsRepository.load().showOverlay
    ) {
        if (overlayEnabled && isMuted) statusOverlay.showMuted(lastPackageName)
        else statusOverlay.dismiss()

        sendBroadcast(StatusContract.intent(this, text, isMuted, lastPackageName))
    }
}
